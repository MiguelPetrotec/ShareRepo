import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IgxExcelExporterService } from 'igniteui-angular';
import { CRMComponent } from './crm.component';


describe('CRMComponent', () => {
  let component: CRMComponent;
  let fixture: ComponentFixture<CRMComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CRMComponent ],
      imports: [
        // FormsModule,
        // BrowserAnimationsModule,
        // IgxGridModule,
        // IgxAvatarModule,
        // IgxBadgeModule,
        // IgxButtonModule,
        // IgxIconModule,
        // IgxInputGroupModule,
        // IgxProgressBarModule,
        // IgxRippleModule,
        // IgxSwitchModule,
        // IgxToggleModule,
        // IgxCheckboxModule
      ],
      providers: [IgxExcelExporterService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CRMComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
