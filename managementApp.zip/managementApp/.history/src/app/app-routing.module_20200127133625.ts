import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';

import { PageNotFoundComponent } from './error-routing/not-found/not-found.component';
import { UncaughtErrorComponent } from './error-routing/error/uncaught-error.component';
import { ErrorRoutingModule } from './error-routing/error-routing.module';
import { PartyComponent } from './party/party.component';
import { CRMComponent } from './crm/crm.component';

export const routes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: 'home', component: HomeComponent, data: { text: 'Home', iconName: 'call_made' } },
  { path: 'error', component: UncaughtErrorComponent },
  { path: 'party', component: PartyComponent, data: { text: 'Party', iconName: 'grid_on' } },
  { path: 'customer', redirectTo: '/customers', pathMatch: 'full' },
  { path: 'crm', component: CRMComponent, data: { text: 'CRM', iconName: 'grid_on' } },
  { path: '**', component: PageNotFoundComponent } // must always be last
];

@NgModule({
  imports: [RouterModule.forRoot(routes), ErrorRoutingModule],
  exports: [RouterModule, ErrorRoutingModule]
})
export class AppRoutingModule {
}
