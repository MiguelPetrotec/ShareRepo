import { CommonModule, registerLocaleData } from '@angular/common';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import localePtPt from '@angular/common/locales/pt-PT';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { Router } from '@angular/router';
import { FaIconLibrary, FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { faChalkboard, faCoffee, fas, faUserTag } from '@fortawesome/free-solid-svg-icons';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import {
  IgxAvatarModule, IgxBadgeModule, IgxButtonModule, IgxCardModule, IgxCheckboxModule,
  IgxExcelExporterService, IgxGridModule, IgxIconModule, IgxInputGroupModule, IgxLayoutModule,
  IgxNavbarModule, IgxNavigationDrawerModule, IgxProgressBarModule, IgxRippleModule,
  IgxSwitchModule, IgxTabsModule, IgxToggleModule
} from 'igniteui-angular';
import { NgxFlagIconCssModule } from 'ngx-flag-icon-css';
import { environment } from 'src/environments/environment';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { languageLoader } from './custom-loader/languageLoader';
import { ErrorRoutingModule } from './error-routing/error-routing.module';
import { AuthGuard } from './shared';
import { PageHeaderModule } from './shared/modules';
import { LanguageTranslationModule } from './shared/modules/language-translation/language-translation.module';
import { LanguagesManagementEffects } from './store/effects/languages-management/languages-management.effect';
import { LoginEffects } from './store/effects/login/login.effects';
import { MessagesEffects } from './store/effects/messages/message.effects';
import { NotifiablesEffects } from './store/effects/notifiables/notifiables.effects';
import { PartiesEffects } from './store/effects/parties/parties.effects';
import { SiteGroupEffects } from './store/effects/site-group/site-group.effects';
import { SitesEffects } from './store/effects/sites/site.effects';
import { UsersEffects } from './store/effects/users/user.effects';
import { metaReducers, reducers } from './store/reducers';
import { AuthenticationModule } from './authentication/authentication.module';
import { AppSessionService } from './shared/services/app-session/app-session.service';
import { BasicAuthInterceptor } from './http-component/basic-authInterceptor';


registerLocaleData(localePtPt);

// export function appInitializerFactory(injector: Injector) {
//     return () => {
//         return new Promise<boolean>((resolve, reject) => {
//             let appSessionService: AppSessionService = injector.get(AppSessionService);
//             // console.log('estou aqui');
//             appSessionService.ngOnInit();
//             resolve(true);
//         });
//     };
// }

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    BrowserModule,
    BrowserAnimationsModule,
    HttpClientModule,
    FontAwesomeModule,
    LanguageTranslationModule,
    PageHeaderModule,
    ErrorRoutingModule,
    AuthenticationModule,
    TranslateModule.forRoot({
      loader: { provide: TranslateLoader, useClass: languageLoader }
    }),
    StoreModule.forRoot(reducers, { metaReducers }),
    !environment.production ? StoreDevtoolsModule.instrument() : [],
    EffectsModule.forRoot(
      [
        LoginEffects,
        UsersEffects,
        SitesEffects,
        SiteGroupEffects,
        MessagesEffects,
        NotifiablesEffects,
        LanguagesManagementEffects,
        PartiesEffects
      ]),
    NgxFlagIconCssModule,
    // NOTE: `AuthenticationModule` defines child routes, must be imported before root `AppRoutingModule`
    AppRoutingModule,
    IgxNavigationDrawerModule,
    IgxNavbarModule,
    IgxLayoutModule,
    IgxRippleModule,
    IgxGridModule,
    IgxCheckboxModule,
    IgxAvatarModule,
    IgxBadgeModule,
    IgxButtonModule,
    IgxIconModule,
    IgxInputGroupModule,
    IgxProgressBarModule,
    IgxSwitchModule,
    IgxToggleModule,
    IgxTabsModule,
    IgxCardModule,
  ],
  providers: [IgxExcelExporterService,
    AuthGuard,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: BasicAuthInterceptor,
      multi: true
    },
    AppSessionService],
  bootstrap: [AppComponent]
})
export class AppModule {

  // constructor(private externalAuthService: ExternalAuthService, router: Router, library: FaIconLibrary) {
  constructor(router: Router, library: FaIconLibrary) {
    /**
     * To register a social login, un-comment one or more of the following and add your service provider Client ID.
     * See https://github.com/IgniteUI/igniteui-cli/wiki/Angular-Authentication-Project-Template#add-a-third-party-social-provider
     */
    // this.externalAuthService.addGoogle('<CLIENT_ID>');

    // this.externalAuthService.addMicrosoft('<CLIENT_ID>');

    // this.externalAuthService.addFacebook('<CLIENT_ID>');

    library.addIconPacks(fas);
    library.addIcons(faCoffee);
    library.addIcons(faUserTag);
    library.addIcons(faChalkboard);

  }
}
