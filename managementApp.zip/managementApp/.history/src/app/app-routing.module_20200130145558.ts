import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';

import { PageNotFoundComponent } from './error-routing/not-found/not-found.component';
import { UncaughtErrorComponent } from './error-routing/error/uncaught-error.component';
import { ErrorRoutingModule } from './error-routing/error-routing.module';
import { PartyComponent } from './party/party.component';
import { CRMComponent } from './crm/crm.component';

import { AuthGuard } from './shared';
import { LoginComponent } from './authentication/login/login.component';


// canActivate: [AuthGuard]

export const routes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full'},
  { path: 'home', component: HomeComponent, data: { text: 'Home', iconName: 'call_made' } },
  { path: 'error', component: UncaughtErrorComponent },
  // { path: 'login', component: LoginComponent },
  {
    path: 'customers', loadChildren:
      () => import('./customers/customers.module').then(m => m.CustomersModule)
    , data: { text: 'Customers', iconName: 'grid_on' }
  },
  { path: 'login', component: LoginComponent },
  { path: 'party', component: PartyComponent, data: { text: 'Party', iconName: 'grid_on' } },
  { path: 'crm', component: CRMComponent, data: { text: 'CRM', iconName: 'grid_on' } },
  { path: '**', component: PageNotFoundComponent } // must always be last
];

@NgModule({
  imports: [RouterModule.forRoot(routes), ErrorRoutingModule],
  exports: [RouterModule, ErrorRoutingModule]
})
export class AppRoutingModule {
}
