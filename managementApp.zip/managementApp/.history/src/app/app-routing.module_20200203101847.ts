import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from './shared';
import { UncaughtErrorComponent } from './error-routing/error/uncaught-error.component';
import { PageNotFoundComponent } from './error-routing/not-found/not-found.component';

// canActivate: [AuthGuard]

const routes: Routes = [
  { path: '', loadChildren: () => import('./layout/layout.module').then(m => m.LayoutModule),canActivate: [AuthGuard] },
  { path: 'login', loadChildren: () => import('./authentication/authentication.module').then(m => m.AuthenticationModule) },
  { path: 'error', component: UncaughtErrorComponent },
  // tslint:disable-next-line:max-line-length
  // { path: 'access-denied', loadChildren: () => import('./http-component/access-denied/access-denied.module').then(m => m.AccessDeniedModule) },
  { path: 'not-found', component: PageNotFoundComponent},
  { path: '**', redirectTo: 'not-found' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {
}
