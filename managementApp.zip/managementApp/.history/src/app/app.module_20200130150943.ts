import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {
  IgxLayoutModule, IgxRippleModule, IgxNavigationDrawerModule, IgxNavbarModule, IgxGridModule, IgxCheckboxModule, IgxExcelExporterService,
  IgxAvatarModule, IgxBadgeModule, IgxButtonModule, IgxIconModule, IgxInputGroupModule, IgxProgressBarModule, IgxSwitchModule,
  IgxToggleModule, IgxTabsModule, IgxCardModule
} from 'igniteui-angular';

import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { AppRoutingModule } from './app-routing.module';
import { AuthenticationModule, ExternalAuthService } from './authentication';
import { PartyComponent } from './party/party.component';
import { CRMComponent } from './crm/crm.component';
import { CustomersModule } from './customers/customers.module';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { LanguageTranslationModule } from './shared/modules/language-translation/language-translation.module';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { languageLoader } from './custom-loader/languageLoader';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { reducers, metaReducers } from './store/reducers';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { NgxFlagIconCssModule } from 'ngx-flag-icon-css';
import localePtPt from '@angular/common/locales/pt-PT';
import { LanguagesManagementEffects } from './store/effects/languages-management/languages-management.effect';
import { environment } from 'src/environments/environment';
import { LoginEffects } from './store/effects/login/login.effects';
import { UsersEffects } from './store/effects/users/user.effects';
import { SitesEffects } from './store/effects/sites/site.effects';
import { SiteGroupEffects } from './store/effects/site-group/site-group.effects';
import { MessagesEffects } from './store/effects/messages/message.effects';
import { NotifiablesEffects } from './store/effects/notifiables/notifiables.effects';
import { PartiesEffects } from './store/effects/parties/parties.effects';
import { registerLocaleData } from '@angular/common';
import { FontAwesomeModule, FaIconLibrary } from '@fortawesome/angular-fontawesome';
import { faCoffee, faChalkboard, faUserTag, fas } from '@fortawesome/free-solid-svg-icons';
import { PageHeaderModule } from './shared/modules';
// import { LoginComponent } from './authentication/login/login.component';
import { AuthGuard } from './shared';
import { LoadingSpinnerComponent } from './loading-spinner/loading-spinner.component';


// import { library } from '@fortawesome/fontawesome-svg-core';
// import { faCoffee, faChalkboard, faUserTag } from '@fortawesome/free-solid-svg-icons';
// library.add(faCoffee);
// library.add(faUserTag);
// library.add(faChalkboard);

registerLocaleData(localePtPt);

// export function appInitializerFactory(injector: Injector) {
//     return () => {
//         return new Promise<boolean>((resolve, reject) => {
//             let appSessionService: AppSessionService = injector.get(AppSessionService);
//             // console.log('estou aqui');
//             appSessionService.ngOnInit();
//             resolve(true);
//         });
//     };
// }

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    PartyComponent,
    CRMComponent,
    LoadingSpinnerComponent
    // LoginComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    BrowserModule,
    AuthenticationModule,
    BrowserAnimationsModule,
    HttpClientModule,
    FontAwesomeModule,
    LanguageTranslationModule,
    PageHeaderModule,
    TranslateModule.forRoot({
      loader: { provide: TranslateLoader, useClass: languageLoader }
    }),
    CustomersModule,
    StoreModule.forRoot(reducers, { metaReducers }),
    !environment.production ? StoreDevtoolsModule.instrument() : [],
    EffectsModule.forRoot(
      [
        LoginEffects,
        UsersEffects,
        SitesEffects,
        SiteGroupEffects,
        MessagesEffects,
        NotifiablesEffects,
        LanguagesManagementEffects,
        PartiesEffects
      ]),
    NgxFlagIconCssModule,
    // NOTE: `AuthenticationModule` defines child routes, must be imported before root `AppRoutingModule`
    AuthenticationModule,
    AppRoutingModule,
    IgxNavigationDrawerModule,
    IgxNavbarModule,
    IgxLayoutModule,
    IgxRippleModule,
    IgxGridModule,
    IgxCheckboxModule,
    IgxAvatarModule,
    IgxBadgeModule,
    IgxButtonModule,
    IgxIconModule,
    IgxInputGroupModule,
    IgxProgressBarModule,
    IgxSwitchModule,
    IgxToggleModule,
    IgxTabsModule,
    IgxCardModule,
  ],
  providers: [IgxExcelExporterService, AuthGuard],
  bootstrap: [AppComponent]
})
export class AppModule {

  constructor(private externalAuthService: ExternalAuthService, router: Router, library: FaIconLibrary) {
    /**
     * To register a social login, un-comment one or more of the following and add your service provider Client ID.
     * See https://github.com/IgniteUI/igniteui-cli/wiki/Angular-Authentication-Project-Template#add-a-third-party-social-provider
     */
    // this.externalAuthService.addGoogle('<CLIENT_ID>');

    // this.externalAuthService.addMicrosoft('<CLIENT_ID>');

    // this.externalAuthService.addFacebook('<CLIENT_ID>');

    library.addIconPacks(fas);
    library.addIcons(faCoffee);
    library.addIcons(faUserTag);
    library.addIcons(faChalkboard);

  }
}
