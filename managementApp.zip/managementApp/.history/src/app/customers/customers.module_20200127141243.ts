import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CustomersComponent } from './customers.component';
import { CustomersRoutingModule } from './customers-routing.module';
import { CustomerDetailComponent } from './customerDetail/customer-detail.component';
import { CustomerListComponent } from './CustomerList/customer-list.component';
import { FormsModule } from '@angular/forms';

@NgModule({
  imports: [
    CommonModule,
    CustomersRoutingModule,
    FormsModule,
    IgxButtonModule,
  ],
  declarations: [
    CustomerListComponent,
    CustomerDetailComponent
  ]
})
export class CustomersModule { }
