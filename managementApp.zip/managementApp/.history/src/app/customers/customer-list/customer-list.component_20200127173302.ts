import { Component, OnInit, Renderer2, ViewChild, HostListener } from '@angular/core';
import { IgxGridComponent } from 'igniteui-angular';
import { employeesData } from '../localData';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';


@Component({
  selector: 'app-customer-list',
  templateUrl: './customer-list.component.html',
  styleUrls: ['./customer-list.component.scss']
})
export class CustomerListComponent implements OnInit {

  @ViewChild('grid1', { static: false }) public grid1: IgxGridComponent;
  public localData: any[];
  title = 'Party';
  private windowWidth: any;

  public density = 'comfortable';
  public displayDensities;

  constructor(private renderer: Renderer2, private router: Router) { }

  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.windowWidth = event.target.innerWidth;
    console.log('coisas');
    // this.grid1.
    this.grid1.reflow();
  }

  stuff() {
    console.log('resize!!');
    this.grid1.reflow();
  }

  ngOnInit() {
    this.localData = employeesData;

    this.displayDensities = [
      {
        label: 'compact',
        selected: this.density === 'compact',
        togglable: true
      },
      {
        label: 'cosy',
        selected: this.density === 'cosy',
        togglable: true
      },
      {
        label: 'comfortable',
        selected: this.density === 'comfortable',
        togglable: true
      }
    ];

    this.windowWidth = window.innerWidth;
  }

  public selectDensity(event) {
    this.density = this.displayDensities[event.index].label;
    this.grid1.displayDensity = this.displayDensities[event.index].label;
    this.grid1.reflow();
  }

  public addCustomer() {
    // this.router.navigate(['/customer', 1]);
    this.router.navigate(['/customer']);
  }

  public doubleClick($event) {
    
    console.dir(this.grid1.selectedRows());
    this.router.navigate(['/customer']);

  }

}
