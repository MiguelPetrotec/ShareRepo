import { Routes, RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';

const customersRoutes: Routes = [
  {},
];

@NgModule({
  imports: [
    RouterModule.forChild(customersRoutes)
  ],
  exports: [
    RouterModule
  ]
})

export class CustomersRoutingModule { }

