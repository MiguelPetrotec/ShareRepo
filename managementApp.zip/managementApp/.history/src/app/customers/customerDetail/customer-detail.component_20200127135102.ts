import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customerDetail',
  templateUrl: './customerDetail.component.html',
  styleUrls: ['./customerDetail.component.css']
})
export class CustomerDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
