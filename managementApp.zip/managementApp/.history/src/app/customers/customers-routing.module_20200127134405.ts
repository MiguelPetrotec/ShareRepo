import { Routes, RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';

const customersRoutes: Routes = [
  { path: 'customers',  component: CustomersListComponent, data: { animation: 'heroes' } },
  { path: 'customer/:id', component: CustomerDetailComponent, data: { animation: 'hero' } }
];

@NgModule({
  imports: [
    RouterModule.forChild(customersRoutes)
  ],
  exports: [
    RouterModule
  ]
})

export class CustomersRoutingModule { }

