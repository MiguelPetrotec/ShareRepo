import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { IgxAvatarModule, IgxBadgeModule, IgxButtonModule, IgxCheckboxModule, IgxGridModule,
   IgxIconModule, IgxInputGroupModule, IgxLayoutModule, IgxProgressBarModule, IgxRippleModule,
   IgxSwitchModule, IgxToggleModule, IgxTabsModule, IgxCardModule } from 'igniteui-angular';
import { CustomerDetailComponent } from './customer-detail/customer-detail.component';
import { CustomerListComponent } from './customer-list/customer-list.component';
import { CustomersRoutingModule } from './customers-routing.module';
import { PageHeaderModule } from '../shared/modules';
import { BasicDataModule } from '../shared/modules/party/basic-data/basic-data.module';


@NgModule({
  imports: [
    CommonModule,
    PageHeaderModule,
    CustomersRoutingModule,
    FormsModule,
    IgxButtonModule,
    IgxLayoutModule,
    IgxRippleModule,
    IgxGridModule,
    IgxCheckboxModule,
    IgxAvatarModule,
    IgxBadgeModule,
    IgxButtonModule,
    IgxIconModule,
    IgxInputGroupModule,
    IgxProgressBarModule,
    IgxSwitchModule,
    IgxToggleModule,
    IgxTabsModule,
    IgxCardModule,
    BasicDataModule
  ],
  declarations: [
    CustomerListComponent,
    CustomerDetailComponent
  ]
})
export class CustomersModule { }
