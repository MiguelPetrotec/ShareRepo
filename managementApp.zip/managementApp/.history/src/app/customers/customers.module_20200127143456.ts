import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { IgxAvatarModule, IgxBadgeModule, IgxButtonModule, IgxCheckboxModule, IgxGridModule,
   IgxIconModule, IgxInputGroupModule, IgxLayoutModule, IgxProgressBarModule, IgxRippleModule,
   IgxSwitchModule, IgxToggleModule } from 'igniteui-angular';
import { CustomerDetailComponent } from './customerDetail/customer-detail.component';
import { CustomerListComponent } from './CustomerList/customer-list.component';
import { CustomersRoutingModule } from './customers-routing.module';

@NgModule({
  imports: [
    CommonModule,
    CustomersRoutingModule,
    FormsModule,
    IgxButtonModule,
    IgxLayoutModule,
    IgxRippleModule,
    IgxGridModule,
    IgxCheckboxModule,
    IgxAvatarModule,
    IgxBadgeModule,
    IgxButtonModule,
    IgxIconModule,
    IgxInputGroupModule,
    IgxProgressBarModule,
    IgxSwitchModule,
    IgxToggleModule,
  ],
  declarations: [
    CustomerListComponent,
    CustomerDetailComponent
  ]
})
export class CustomersModule { }
