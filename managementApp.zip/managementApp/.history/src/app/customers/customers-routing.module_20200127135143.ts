import { Routes, RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';
import { CustomerListComponent } from './CustomerList/customer-list.component';

const customersRoutes: Routes = [
  { path: 'customers',  component: CustomerListComponent, data: { animation: 'heroes' } },
  { path: 'customer/:id', component: CustomerDetailComponent, data: { animation: 'hero' } }
];

@NgModule({
  imports: [
    RouterModule.forChild(customersRoutes)
  ],
  exports: [
    RouterModule
  ]
})

export class CustomersRoutingModule { }

