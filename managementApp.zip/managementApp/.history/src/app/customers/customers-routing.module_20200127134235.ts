import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  {  },
];

export const CustomersRouting.moduleRoutes = RouterModule.forChild(routes);
