import { Component, OnInit, AfterViewInit } from '@angular/core';
// import { AngularFireAuth } from '@angular/fire/auth';
import { Router, ActivatedRoute } from '@angular/router';
import { moveIn } from 'src/app/router.animations';
import { AppSessionService } from 'src/app/shared/services/app-session/app-session.service';
import { authenticate } from 'src/app/store/actions/login/login.actions';
import { Store } from '@ngrx/store';
import { AppState } from 'src/app/store/reducers';
import { TranslateService } from '@ngx-translate/core';
import { version } from '../../../../package.json';
import { User } from 'src/app/models/user';

// import * as firebase from 'firebase/app';

@Component({
   selector: 'app-login',
   templateUrl: './login.component.html',
   styleUrls: ['./login.component.scss'],
   animations: [moveIn()],
   host: { '[@moveIn]': '' }
})
export class LoginComponent implements OnInit, AfterViewInit {
   return = '';
   error: any;
   //  googleAuthProvider = new firebase.auth.GoogleAuthProvider();
   //  facebookAuthProvider = new firebase.auth.FacebookAuthProvider();

   // messageSubs: Subscription;
   // message$: Observable<AppMessage>;
   // isLoading$: Observable<boolean>;
   private version: String = version;
   appName: string = '';


   showSpinner = localStorage.getItem('showSpinner') === 'true' ? true : false;
   //  constructor(public afAuth: AngularFireAuth, private router: Router, private route: ActivatedRoute) {
   constructor(
      private router: Router,
      // private route: ActivatedRoute,
      public session: AppSessionService,
      private store: Store<AppState>,
      // private messageService: MessageService,
      private translate: TranslateService,
   ) {

      // this.afAuth.authState.subscribe(auth => {
      //    localStorage.setItem('showSpinner', 'false');
      //    if (auth) {
      //       this.router.navigateByUrl(this.return);
      //    }
      // });

   }

   ngOnInit() {
      this.user = new User();
      // Get the query params
      // this.route.queryParams
      //    .subscribe(params => this.return = params['return'] || '/home');
   }

   ngAfterViewInit() {
   }

   //  loginFb() {
   //     this.showSpinner = true;
   //     localStorage.setItem('showSpinner', 'true');
   //     this.afAuth.auth.signInWithRedirect(this.facebookAuthProvider);
   //     this.afAuth.auth.getRedirectResult().then(result => {
   //        if (result.user) {
   //           this.showSpinner = true;
   //           localStorage.setItem('showSpinner', 'true');
   //           this.router.navigate([this.return]);
   //        }
   //     }).catch(function (error) {
   //        // Handle Errors here.
   //        const errorCode = error.code;
   //        const errorMessage = error.message;
   //        this.error = errorMessage;
   //     });
   //  }

   //  loginGoogle() {
   //     this.afAuth.auth.signInWithRedirect(this.googleAuthProvider).then(
   //        (success) => {
   //           this.router.navigate([this.return]);
   //        }).catch(
   //           (err) => {
   //              this.error = err;
   //        });
   //  }


   onLoggedin() {

      this.store.dispatch(authenticate({ user: this.user }));

      let prefix: string = "/assets/images/";
      let img = "grupo-petrotec-logo5.png";
      // let img: string = "galplogo.png";
      let fullpath: string = "http://www.galpenergia.com/Style%20Library/Images/twitter_share.jpg";
      let url = "url('" + fullpath + "')";
      // let url = "url('"+ fullpath + "')";
      console.dir(url);
      // document.documentElement.style.setProperty('--url', url);
      // document.documentElement.style.setProperty('--first-color', 'pink');
   }

   loginEmail() {
      this.router.navigate(['/email'], {
         queryParams: {
            return: this.return
         }
      });
   }
}
