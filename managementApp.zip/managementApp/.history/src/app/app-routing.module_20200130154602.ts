import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from './shared';

// canActivate: [AuthGuard]

const routes: Routes = [
  { path: '', loadChildren: () => import('./layout/layout.module').then(m => m.LayoutModule), canActivate: [AuthGuard] },
  { path: 'login', loadChildren: () => import('./user-component/login/login.module').then(m => m.LoginModule) },
  { path: 'signup', loadChildren: () => import('./user-component/signup/signup.module').then(m => m.SignupModule) },
  { path: 'error', loadChildren: () => import('./http-component/server-error/server-error.module').then(m => m.ServerErrorModule) },
  // tslint:disable-next-line:max-line-length
  { path: 'access-denied', loadChildren: () => import('./http-component/access-denied/access-denied.module').then(m => m.AccessDeniedModule) },
  { path: 'not-found', loadChildren: () => import('./http-component/not-found/not-found.module').then(m => m.NotFoundModule) },
  { path: '**', redirectTo: 'not-found' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {
}
