import { Component, OnInit, Renderer2, ViewChild, HostListener } from '@angular/core';
import { IgxGridComponent, IgxComboComponent, IComboSelectionChangeEventArgs } from 'igniteui-angular';
import { employeesData } from '../localData';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { AppState } from 'src/app/store/reducers';
import { Store } from '@ngrx/store';
import { ICity, CITIES } from './cities';


@Component({
  selector: 'app-customer-list',
  templateUrl: './customer-list.component.html',
  styleUrls: ['./customer-list.component.scss']
})
export class CustomerListComponent implements OnInit {

  @ViewChild('withValueKey', { read: IgxComboComponent, static: false })
  public comboValueKey: IgxComboComponent;
  @ViewChild('noValueKey', { read: IgxComboComponent, static: false })
  public comboNoValueKey: IgxComboComponent;

  public cities: ICity[] = CITIES;
  public selectedValueKey: string[] = ['UK01', 'BG01'];
  public selectedNoValueKey: ICity[] = [this.cities[4], this.cities[0]];



  @ViewChild('grid1', { static: false }) public grid1: IgxGridComponent;
  public localData: any[];
  title = 'Party';
  private windowWidth: any;

  public density = 'comfortable';
  public displayDensities;

  constructor(private renderer: Renderer2, private router: Router, private store: Store<AppState>) { }

  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.windowWidth = event.target.innerWidth;
    console.log('coisas');
    // this.grid1.
    this.grid1.reflow();
  }

  // stuff() {
  //   console.log('resize!!');
  //   this.grid1.reflow();
  // }

  ngOnInit() {
    this.localData = employeesData;
    console.log('vaya con dios!!!');
    this.displayDensities = [
      {
        label: 'compact',
        selected: this.density === 'compact',
        togglable: true
      },
      {
        label: 'cosy',
        selected: this.density === 'cosy',
        togglable: true
      },
      {
        label: 'comfortable',
        selected: this.density === 'comfortable',
        togglable: true
      }
    ];

    this.windowWidth = window.innerWidth;
  }




  public handleSelectionChange(event: IComboSelectionChangeEventArgs) {
    console.log(event);
  }

  public selectFavorites(valueKey: boolean) {
    if (valueKey) {
      this.comboValueKey.selectItems(['UK01', 'BG01', 'DE01', 'JP01']);
    } else {
      const selectedItems: ICity[] = this.cities.filter((e: ICity) => {
        return ['UK01', 'BG01', 'DE01', 'JP01'].indexOf(e.id) > -1;
      });
      this.comboNoValueKey.selectItems(selectedItems);
    }
  }

  public selectDensity(event) {
    this.density = this.displayDensities[event.index].label;
    this.grid1.displayDensity = this.displayDensities[event.index].label;
    this.grid1.reflow();
  }

  public addCustomer() {
    // this.router.navigate(['/customer', 1]);
    this.router.navigate(['/customer']);
  }

  public doubleClick($event) {
    console.dir($event);
    console.dir($event.cell.rowData);
    this.router.navigate(['/customer', $event.cell.rowData.EmployeeID]);

  }

}
