import { Action, createReducer, on } from '@ngrx/store';
import { UserDTO } from 'src/app/models/UserDetails/userDTO';
import * as UsersActionTypes from '../../actions/users/user.actions';
import { PaginationRequest } from 'src/app/models/common/paginationRequest';
import { UserProfileDTO } from 'src/app/models/UserDetails/userProfileDTO';


export interface UsersState {
  userList?: UserDTO[];
  isLoading: boolean;
  error: Error;
  user: UserDTO;
  userProfilesList?: UserProfileDTO[];
  localesList?: any[];
  totalRecords: number;
  pageReq: PaginationRequest;
}

export const initialState: UsersState = {
  userList: null,
  isLoading: false,
  error: null,
  user: null,
  userProfilesList: null,
  localesList: null,
  totalRecords: 0,
  pageReq: null
};

const usersReducer = createReducer(
  initialState,
  on(UsersActionTypes.getUsers, (state, { pageReq }) => (<UsersState>{
    ...state, error: null, pageReq: pageReq
  })),
  on(UsersActionTypes.refreshUsers, (state) => (<UsersState>{ ...state, isLoading: false, error: null })),
  on(UsersActionTypes.loadUsers, (state, { response }) => {
    let currentOffset = state.pageReq ? state.pageReq.offset : 0;
    let totalRecords = Math.max(currentOffset + (<any>response).result.size, state.totalRecords);
    return {
      ...state, userList: (<any>response).result.items || [], isLoading: false, error: null, totalRecords: totalRecords
    }
  }),
  on(UsersActionTypes.setUser, (state, { user }) => ({
    ...state, user: user, error: null
  })),
  on(UsersActionTypes.setUserProfiles, (state, { userProfiles }) => ({
    ...state,
    userProfilesList: (<any>userProfiles).result.items || [],  
    error: null
  })),
  on(UsersActionTypes.loadLocales, (state, { response }) => ({
    ...state, localesList: (<any>response).result.items || [], error: null
  })),
  on(UsersActionTypes.loadUsersLoadStart, (state) => ({
    ...state, isLoading: true, error: null
  })),
  on(UsersActionTypes.loadUsersLoadEnd, (state) => ({
    ...state, isLoading: false, error: null
  }))
);


export function reducer(state: UsersState | undefined, action: Action) {

  return usersReducer(state, action);
}
