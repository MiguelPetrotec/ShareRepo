import { createAction, props } from '@ngrx/store';
import { UserCreateDTO } from 'src/app/models/UserDetails/userCreateDTO';
import { UserUpdateDTO } from 'src/app/models/UserDetails/userUpdateDTO';
import { PaginationRequest } from 'src/app/models/common/paginationRequest';

export const getUsers = createAction('[User] Get All User Action', props<{ pageReq: PaginationRequest }>());
export const refreshUsers = createAction('[User] Refresh Users Action');
export const loadUsers = createAction('[User] Load All User Action', props<{ response: any[] }>());
export const loadUsersFailure = createAction('[User] Users Load Action Failure', props<{ error: Error }>());
export const updateUser = createAction('[User] Update User Action', props<{ user: UserUpdateDTO }>());
export const getUser = createAction('[User] Get User Action', props<{ user: any }>());
export const setUser = createAction('[User] Set User Action', props<{ user: any }>());
export const getUserProfiles = createAction('[User] Get All User Profiles Action');
export const setUserProfiles = createAction('[User] Set All User Profiles Action', props<{ userProfiles: any[] }>());
export const changePassword = createAction('[User] Change Password Action', props<{ passwords: any }>());
export const resetUserPassword = createAction('[User] Reset User Password Action', props<{ username: string, newPassword: string }>());
export const getLocales = createAction('[User] Get All Locales Action');
export const loadLocales = createAction('[User] Load All Locales Action', props<{ response: any }>());
export const changeStatus = createAction('[User] Change User Status Action', props<{ usernames: any[], enabled: any }>());
export const createUser = createAction('[User] Create User Action', props<{ user: UserCreateDTO }>());
export const loadUsersLoadStart = createAction('[User] Load Start Action');
export const loadUsersLoadEnd = createAction('[User] Load End Action');

