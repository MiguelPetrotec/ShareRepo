import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { Store } from '@ngrx/store';
import { TranslateService } from '@ngx-translate/core';
import { of } from 'rxjs';
import { catchError, exhaustMap, map, tap } from 'rxjs/operators';
import { LoginService } from 'src/app/shared/services/login/login.service';
import * as LoginActionTypes from '../../actions/login/login.actions';
import * as MessagesActionTypes from '../../actions/messages/message.actions';
import * as UserActionTypes from '../../actions/users/user.actions';
import { AppState } from '../../reducers';

@Injectable()
export class LoginEffects {

    //   @Effect()
    //   authenticate$ = this.actions$
    //     .pipe(
    //       ofType('[Login] Authenticate Action'),
    //       mergeMap((action) => this.loginService.logIn(action.user)
    //       .pipe(
    //         map(userSession => ({type: '[Login] Login Action Success', payload: UserSession})),
    //         catchError((errorMessage) => EMPTY))// of(new LocationsError({error: errorMessage})))
    //       ));

    //   login$ = createEffect( () => this.actions$.pipe(
    //     ofType(Authenticate),
    //     exhaustMap( action => this.loginService.logIn(action.user)
    //       .pipe(
    //         map(userSession => (LoginSuccess, { userSession })),
    //         catchError(() => EMPTY)
    //       ))
    //     );
    //   )



    authenticate$ = createEffect(() =>
        this.actions$
            .pipe(
                ofType('[Login] Authenticate Action'),
                exhaustMap((action) => this.loginService.logIn(action)// this.loginService.logIn(action)
                    .pipe(
                        map(userSession => LoginActionTypes.loginSuccess({ authenticatedUser: userSession })
                            // map(userSession => this.onLogIn(userSession ))
                        ),
                        // catchError(() => of({ type: '[Movies API] Movies Loaded Error' }))
                        catchError(
                            (error) => of(LoginActionTypes.loginFailure({ error }))
                        )
                    )
                )
            )
    );

    loginFail$ = createEffect(() =>
        this.actions$
            .pipe(
                ofType(LoginActionTypes.loginFailure),
                tap(() =>
                    this.store.dispatch(MessagesActionTypes.setMessage({
                        appMessage: {
                            message: 'App.Errors.BadCredentials',
                            owner: this.translate.instant('App.Errors.Error'),
                            severity: 'error',
                            timestamp: new Date().getTime()
                        }
                    })
                    )
                ),
                catchError((error) => of(LoginActionTypes.loginFailure({ error })))
            ), { dispatch: false }
    );



    authenticateSuccess$ = createEffect(() =>
        this.actions$
            .pipe(
                ofType('[Login] Login Action Success'),
                tap((payload) => {
                    sessionStorage.setItem('isAuthenticated', 'true');
                    sessionStorage.setItem('access_token', (payload as any).authenticatedUser.access_token);
                    sessionStorage.setItem('refresh_token', ( payload as any).authenticatedUser.refresh_token);
                    sessionStorage.setItem('entity_code', ( payload as any).authenticatedUser.entity_code);
                    sessionStorage.setItem('rank_order', ( payload as any).authenticatedUser.rank_order);
                    sessionStorage.setItem('locale', ( payload as any).authenticatedUser.locale);
                    this.store.dispatch(UserActionTypes.getUser({ user: sessionStorage.getItem('username') }));
                }
                ),
                catchError((error) => of(LoginActionTypes.loginFailure({ error })))
            ), { dispatch: false }
    );


    logOut$ = createEffect(() =>
        this.actions$
            .pipe(
                ofType('[Login] LogOut Action Success'),
                exhaustMap(() => this.loginService.logOut())
            ));

    constructor(
        private actions$: Actions,
        private store: Store<AppState>,
        private loginService: LoginService,
        private router: Router,
        private translate: TranslateService
    ) {


    }

}
