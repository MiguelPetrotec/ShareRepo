/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { LocalesService } from './locales.service';

describe('Service: Locales', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [LocalesService]
    });
  });

  it('should ...', inject([LocalesService], (service: LocalesService) => {
    expect(service).toBeTruthy();
  }));
});
