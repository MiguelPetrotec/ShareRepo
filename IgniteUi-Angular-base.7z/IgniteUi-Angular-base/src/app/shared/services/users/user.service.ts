import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { AppState } from 'src/app/store/reducers';
import { environment } from '../../../../environments/environment';
import { PaginationRequest } from 'src/app/models/common/paginationRequest';

@Injectable({
    providedIn: 'root'
})
export class UsersService {

    private BASE_URL = environment.apiGatewayUrl + '/api/v1';

    constructor(private http: HttpClient, private store: Store<AppState>) { }


    getUsers(pageReq: PaginationRequest): Observable<any> {

        const headers = new HttpHeaders({
            'Content-type': 'application/x-www-form-urlencoded; charset=utf-8',
        });

        let url = `${this.BASE_URL}/users`;
        if (!pageReq) {
            // pageReq not defined
            pageReq = {
                offset: 0,
                limit: 40,
                realSize: true
            }
        }
        const pagination = '?offset=' + pageReq.offset + '&limit=' + pageReq.limit + '&real_size=' + pageReq.realSize + pageReq.sort;
        url = url.concat(pagination);

        return this.http.get(url, { headers });

    }

    updateUser(action): Observable<any> {

        const headers = new HttpHeaders({

            'Content-type': 'application/json'
        });
        const data = JSON.stringify(action.user);
        const url = `${this.BASE_URL}/users/${action.user.username}`;
        return this.http.put(url, data, { headers });

    }

    getUser(action): Observable<any> {

        const headers = new HttpHeaders({

            'Content-type': 'application/json'
        });
        const username = sessionStorage.getItem('username');
        const url = `${this.BASE_URL}/users/${action.user}`;
        return this.http.get(url, { headers });

    }

    getUserProfiles(): Observable<any> {

        const headers = new HttpHeaders({
            'Content-type': 'application/x-www-form-urlencoded; charset=utf-8',
        });

        const url = `${this.BASE_URL}/users/profiles/translated`;
        return this.http.get(url, { headers });

    }

    changePassword(action): Observable<any> {

        const headers = new HttpHeaders({

            'Content-type': 'application/json'
        });
        const username = sessionStorage.getItem('username');
        const data = JSON.stringify({
            'currentPassword': action.currentPassword,
            'newPassword': action.newPassword
        });
        const url = `${this.BASE_URL}/users/${username}/password`;
        return this.http.put(url, data, { headers });

    }

    resetUserPassword(action): Observable<any> {

        const headers = new HttpHeaders({ 'Content-type': 'application/json' });
        const username = action.username;
        const data = JSON.stringify({ 'newPassword': action.newPassword });
        const url = `${this.BASE_URL}/users/${username}/password/reset`;
        return this.http.put(url, data, { headers });
    }

    changeStatus(action): Observable<any> {

        const headers = new HttpHeaders({

            'Content-type': 'application/json'
        });

        const data = JSON.stringify({ codes: action.usernames, enabled: action.enabled });
        const url = `${this.BASE_URL}/users/status`;
        return this.http.put(url, data, { headers });

    }

    createUser(action): Observable<any> {

        const headers = new HttpHeaders({

            'Content-type': 'application/json'
        });

        const data = JSON.stringify(action.user);
        const url = `${this.BASE_URL}/users`;
        return this.http.post(url, data, { headers });

    }

}
