export interface Sort {
    field: string;
    order: string;
}
