
export interface HistoryAction {
    action: number;
    item: any;
}

