export interface Locale {
    code: string;
    value: Map<string, string>;
    enabled: boolean;
}
