export enum SiteGroupEnum {
    CreateSiteGroup,
    CreateSiteGroupItem,
    AddSiteToSiteGroupItem,
    UpdateSiteGroup,
    UpdateSiteGroupItem,   
    DeleteSiteGroup,
    DeleteSiteFromSiteGroupItem
}