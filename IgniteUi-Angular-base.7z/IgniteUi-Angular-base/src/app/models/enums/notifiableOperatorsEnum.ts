export enum NotifiableOperatorsEnum {
    Create = 'CREATE',    
    Update = 'UPDATE',
    Delete = 'DELETE',
    Add = 'ADD',
    Remove = 'REMOVE'
}