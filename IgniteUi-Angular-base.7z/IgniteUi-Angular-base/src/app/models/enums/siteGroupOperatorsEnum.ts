export enum SiteGroupsOperatorsEnum {
    Create = 'CREATE',    
    Update = 'UPDATE',
    Delete = 'DELETE'
}