export interface DictionaryTranslatedDTO {
    namespace: string;
    dictionaryKey: string;
    value: string;
}
