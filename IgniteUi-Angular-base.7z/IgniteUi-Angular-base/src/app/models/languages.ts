export class Languages {
    value: string;
    label: string;
}
