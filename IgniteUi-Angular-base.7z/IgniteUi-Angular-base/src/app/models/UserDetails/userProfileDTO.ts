export class UserProfileDTO {
    code: string;
    description: string;
}
