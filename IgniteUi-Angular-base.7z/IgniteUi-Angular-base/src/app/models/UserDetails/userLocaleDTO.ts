export interface UserLocaleDTO {
    code: string;
    description: string;
}
