export enum DataType {
    TEXT = 'text',
    NUMERIC = 'number',
    DATE = 'date',
    BOOLEAN = 'boolean',
    ENUM = 'enum'
}
