const data: any[] = [
{ field: 'EU', header: true },
{ field: 'Germany' },
{ field: 'Bulgaria' },
{ field: 'UK', disabled: true },
{ field: 'NA', header: true },
{ field: 'Canada' },
{ field: 'USA' },
{ field: 'Mexico' },
{ field: 'SA', header: true },
{ field: 'Brazil' },
{ field: 'Colombia', disabled: true },
{ field: 'Argentina' }];

export { data };

