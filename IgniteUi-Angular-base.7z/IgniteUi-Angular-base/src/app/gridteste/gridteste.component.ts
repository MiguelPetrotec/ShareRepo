import { Component, OnInit, ViewEncapsulation, Renderer2 } from '@angular/core';
import { employeesData } from './localData';

@Component({
  selector: 'app-gridteste',
  templateUrl: './gridteste.component.html',
  styleUrls: ['./gridteste.component.scss']
})
export class GridTesteComponent implements OnInit {
  public localData: any[];
  title = 'GridTeste';
  constructor(private renderer: Renderer2) { }

  ngOnInit() {
    this.localData = employeesData;
  }
}
