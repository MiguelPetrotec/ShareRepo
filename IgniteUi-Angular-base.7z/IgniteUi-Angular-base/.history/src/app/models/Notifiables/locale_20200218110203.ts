export interface Locale {
    code: string,
    value: Map<String, String>,
    enabled: boolean
}
