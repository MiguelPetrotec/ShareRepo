import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { Store, select } from '@ngrx/store';
import { of, EMPTY, from } from 'rxjs';
import { catchError, exhaustMap, map, tap, mergeMap, withLatestFrom, concatMap } from 'rxjs/operators';
import { UsersService } from 'src/app/shared/services/users/user.service';
import { LocalesService } from 'src/app/shared/services/locales/locales.service';
import * as UsersActionTypes from '../../actions/users/user.actions';
import * as MessagesActionTypes from '../../actions/messages/message.actions';
import { AppState, userState } from '../../reducers';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';


@Injectable()
export class UsersEffects {

    getUsers$ = createEffect(() =>
        this.actions$
            .pipe(
                ofType(UsersActionTypes.getUsers),
                exhaustMap((action) => this.usersService.getUsers(action.pageReq)
                    .pipe(
                        map(result => UsersActionTypes.loadUsers({ response: result })),
                        catchError((error) => {
                            console.log("Get users errors");
                            const actions = [
                                UsersActionTypes.loadUsersLoadEnd(),
                                MessagesActionTypes.setMessage(
                                    {
                                        appMessage:
                                            { message: this.translate.instant('App.Errors.Error'), owner: 'UserManagement', severity: 'error', timestamp: new Date().getTime() }
                                    }
                                )
                            ];
                            return from(actions);
                        }
                        )
                    )
                )
            )
    );

    refreshUsers$ = createEffect(() =>
        this.actions$
            .pipe(
                ofType(UsersActionTypes.refreshUsers),
                concatMap(action => of(action).pipe(
                    withLatestFrom(this.store$.pipe(select(userState)))
                )),
                exhaustMap(([action, usersState]) =>
                    this.usersService
                        .getUsers(usersState.pageReq)
                        .pipe(
                            map(result => UsersActionTypes.loadUsers({ response: result })),
                            catchError((error) => of(UsersActionTypes.loadUsersFailure({ error })))
                        )
                )
            )
    );

    updateUser$ = createEffect(() =>
        this.actions$
            .pipe(
                ofType(UsersActionTypes.updateUser),
                exhaustMap((action) => this.usersService.updateUser(action)
                    .pipe(
                        map(_ => UsersActionTypes.refreshUsers()),
                        tap(() =>
                            this.store$.dispatch(MessagesActionTypes.setMessage({
                                appMessage: {
                                    message: 'UserManagement.UserUpdated',
                                    owner: this.translate.instant('App.Success'),
                                    severity: 'success',
                                    timestamp: new Date().getTime()
                                }
                            })
                            )
                        ),

                        catchError((error) => {
                            const actions = [
                                UsersActionTypes.loadUsersLoadEnd(),
                                MessagesActionTypes.setMessage(
                                    {
                                        appMessage:
                                            { message: error ? (error.error ? error.error : error.message) : error, owner: 'UserManagement', severity: 'error', timestamp: new Date().getTime() }
                                    }
                                )
                            ];
                            return from(actions);
                        }
                        )
                    )
                )
            )
    );

    getUser$ = createEffect(() =>
        this.actions$
            .pipe(
                ofType(UsersActionTypes.getUser),
                exhaustMap((action) => this.usersService.getUser(action)
                    .pipe(
                        map(result => (UsersActionTypes.setUser({ user: result }))
                        ),

                        catchError((error) => {
                            const actions = [
                                UsersActionTypes.loadUsersLoadEnd(),
                                MessagesActionTypes.setMessage(
                                    {
                                        appMessage:
                                            { message: this.translate.instant('App.Errors.Error'), owner: 'UserManagement', severity: 'error', timestamp: new Date().getTime() }
                                    }
                                )
                            ];
                            return from(actions);
                        }
                        )
                    )
                )
            )
    );

    getUserSuccess$ = createEffect(() =>
        this.actions$
            .pipe(
                ofType(UsersActionTypes.setUser),
                tap((payload) => {
                    sessionStorage.setItem('loggedUser', (<any>payload).user.result.name);
                    this.router.navigateByUrl('/');
                }
                )
            ), { dispatch: false }
    );


    getUserProfiles$ = createEffect(() =>
        this.actions$
            .pipe(
                ofType(UsersActionTypes.getUserProfiles),
                exhaustMap(() => this.usersService.getUserProfiles()
                    .pipe(
                        map(result => (UsersActionTypes.setUserProfiles({ userProfiles: result }))
                        ),

                        catchError((error) => {
                            const actions = [
                                UsersActionTypes.loadUsersLoadEnd(),
                                MessagesActionTypes.setMessage(
                                    {
                                        appMessage:
                                            { message: this.translate.instant('App.Errors.Error'), owner: 'UserManagement', severity: 'error', timestamp: new Date().getTime() }
                                    }
                                )
                            ];
                            return from(actions);
                        }
                        )
                    )
                )
            )
    );

    resetUserPassword$ = createEffect(() =>
        this.actions$
            .pipe(
                ofType(UsersActionTypes.resetUserPassword),
                exhaustMap((action) => this.usersService.resetUserPassword(action)
                    .pipe(
                        map(result => (UsersActionTypes.getUsers(null))
                        ),
                        tap(() =>
                            this.store$.dispatch(MessagesActionTypes.setMessage({
                                appMessage: {
                                    message: 'UserManagement.PasswordChange',
                                    owner: this.translate.instant('App.Success'),
                                    severity: 'success',
                                    timestamp: new Date().getTime()
                                }
                            })
                            )
                        ),

                        catchError((error) => {
                            const actions = [
                                UsersActionTypes.loadUsersLoadEnd(),
                                MessagesActionTypes.setMessage(
                                    {
                                        appMessage:
                                            { message: this.translate.instant('UserManagement.PasswordChangeFailed'), owner: 'UserManagement', severity: 'error', timestamp: new Date().getTime() }
                                    }
                                )
                            ];
                            return from(actions);
                        }
                        )
                    )
                )
            )
    );

    changePassword$ = createEffect(() =>
        this.actions$
            .pipe(
                ofType(UsersActionTypes.changePassword),
                exhaustMap((action) => this.usersService.changePassword(action.passwords)
                    .pipe(
                        map(() => {

                            this.store$.dispatch(UsersActionTypes.loadUsersLoadEnd());

                            return MessagesActionTypes.setMessage({
                                appMessage: {
                                    message: 'UserManagement.PasswordChange',
                                    owner: this.translate.instant('App.Success'),
                                    severity: 'success',
                                    timestamp: new Date().getTime()
                                }
                            });
                        }),
                        catchError((error) => {
                            const actions = [
                                UsersActionTypes.loadUsersLoadEnd(),
                                MessagesActionTypes.setMessage(
                                    {
                                        appMessage:
                                            { message: this.translate.instant('UserManagement.PasswordChangeFailed'), owner: 'UserManagement', severity: 'error', timestamp: new Date().getTime() }
                                    }
                                )
                            ];
                            return from(actions);
                        }
                        )
                    )
                )
            )
    );

    getLocales$ = createEffect(() =>
        this.actions$
            .pipe(
                ofType(UsersActionTypes.getLocales),
                exhaustMap(() => this.localesService.getLocales()
                    .pipe(
                        map(result => UsersActionTypes.loadLocales({ response: result })
                        ),
                        catchError((error) => {
                            const actions = [
                                UsersActionTypes.loadUsersLoadEnd(),
                                MessagesActionTypes.setMessage(
                                    {
                                        appMessage:
                                            { message: this.translate.instant('App.Errors.Error'), owner: 'UserManagement', severity: 'error', timestamp: new Date().getTime() }
                                    }
                                )
                            ];
                            return from(actions);
                        }
                        )
                    )
                )
            )
    );

    changeStatus$ = createEffect(() =>
        this.actions$
            .pipe(
                ofType(UsersActionTypes.changeStatus),
                exhaustMap((action) => this.usersService.changeStatus(action)
                    .pipe(
                        mergeMap((result) => {
                            return [
                                UsersActionTypes.getUsers(null),
                                MessagesActionTypes.setMessage(
                                    {
                                        appMessage:
                                            { message: 'UserManagement.StatusChange', owner: 'UserManagement', severity: 'success', timestamp: new Date().getTime() }
                                    }
                                )
                            ]

                        }
                        ),
                        catchError((error) => {
                            const actions = [
                                UsersActionTypes.loadUsersLoadEnd(),
                                MessagesActionTypes.setMessage(
                                    {
                                        appMessage:
                                            { message: this.translate.instant('App.Errors.Error'), owner: 'UserManagement', severity: 'error', timestamp: new Date().getTime() }
                                    }
                                )
                            ];
                            return from(actions);
                        }
                        )
                    )
                )
            )
    );




    createUser$ = createEffect(() =>
        this.actions$
            .pipe(
                ofType(UsersActionTypes.createUser),
                exhaustMap((action) => this.usersService.createUser(action)
                    .pipe(
                        map(
                            result => (UsersActionTypes.getUsers(null))
                        ),
                        tap(() =>
                            this.store$.dispatch(MessagesActionTypes.setMessage({
                                appMessage: {
                                    message: 'UserManagement.UserCreated',
                                    owner: this.translate.instant('App.Success'),
                                    severity: 'success',
                                    timestamp: new Date().getTime()
                                }
                            })
                            )
                        ),

                        catchError((error) => {
                            const actions = [
                                UsersActionTypes.loadUsersLoadEnd(),
                                MessagesActionTypes.setMessage(
                                    {
                                        appMessage:
                                            { message: this.translate.instant('UserManagement.UserCreateFailed'), owner: 'UserManagement', severity: 'error', timestamp: new Date().getTime() }
                                    }
                                )
                            ];
                            return from(actions);
                        }
                        )
                    )
                )
            )
    );

    constructor(
        private actions$: Actions,
        private store$: Store<AppState>,
        private usersService: UsersService,
        private router: Router,
        private localesService: LocalesService,
        private translate: TranslateService
    ) { }

}
