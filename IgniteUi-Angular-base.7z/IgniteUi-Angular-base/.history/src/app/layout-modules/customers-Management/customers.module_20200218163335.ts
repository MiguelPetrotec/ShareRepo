// import { CommonModule } from '@angular/common';
// import { NgModule } from '@angular/core';
// import { PageHeaderModule } from 'src/app/shared';
// import { BasicDataModule } from 'src/app/shared/modules/party/basic-data/basic-data.module';
// import { CustomerDetailComponent } from './customer-detail/customer-detail.component';
// import { CustomerListComponent } from './customer-list/customer-list.component';
// import { CustomersRoutingModule } from './customers-routing.module';
// import {
//   IgxGridModule, IgxCheckboxModule, IgxButtonModule, IgxRippleModule, IgxLayoutModule, IgxInputGroupModule,
//   IgxSwitchModule, IgxToggleModule, IgxTabsModule
// } from 'igniteui-angular';
// import { FormsModule } from '@angular/forms';
// import { PageHeaderModule } from 'src/app/shared';



@NgModule({
  imports: [
    // CommonModule,
    // PageHeaderModule,
    // CustomersRoutingModule,
    // FormsModule,
    // IgxButtonModule,
    // IgxLayoutModule,
    // IgxRippleModule,
    // IgxGridModule,
    // IgxCheckboxModule,
    // IgxAvatarModule,
    // IgxBadgeModule,
    // IgxButtonModule,
    // IgxIconModule,
    // IgxInputGroupModule,
    // IgxProgressBarModule,
    // IgxSwitchModule,
    // IgxToggleModule,
    // IgxTabsModule,
    // IgxCardModule,
    // BasicDataModule
  ],
  declarations: [
    // CustomerListComponent,
    // CustomerDetailComponent
  ]
})
export class CustomersModule { }
