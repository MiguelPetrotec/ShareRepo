import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { AppSessionService } from 'src/app/shared/services/app-session/app-session.service';
import { authenticate } from 'src/app/store/actions/login/login.actions';
import { Store } from '@ngrx/store';
import { AppState } from 'src/app/store/reducers';
import { TranslateService } from '@ngx-translate/core';
import { User } from 'src/app/models/user';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})

export class LoginComponent implements OnInit {
  public loginForm: FormGroup;
  public registrationForm: FormGroup;
  public showLogin = true;
  public showRegister = false;
  public showSuccessLogin = false;
  public showSuccessRegister = false;


  // private version: String = version;
  appName = '';

  user: User;

  constructor(
    fb: FormBuilder,
    public session: AppSessionService,
    private store: Store<AppState>,
    private translate: TranslateService,
    private router: Router
  ) {

    this.loginForm = fb.group({
      email: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  ngOnInit() {
    this.user = new User();
    // Get the query params
    // this.route.queryParams
    //    .subscribe(params => this.return = params['return'] || '/home');
  }

  tryLogin() {

    this.user = this.loginForm.value;
    this.store.dispatch(authenticate({ user: this.user }));


    // use loginInfo
    this.showLogin = false;
    this.showSuccessLogin = true;
  }

  showLoginForm() {
    this.showLogin = true;
    this.showRegister = false;
  }
}
